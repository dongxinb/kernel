/* This file is auto generated, version 201903190933 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201903190933 SMP Thu Apr 25 02:41:23 UTC 2019"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ip-172-26-9-32"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu 7.3.0-27ubuntu1~18.04)"
